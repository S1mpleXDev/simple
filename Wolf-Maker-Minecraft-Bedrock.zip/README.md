# Wolf Maker

A static, dependency-free Minecraft Bedrock wolf texture editor.

## Run
Open `index.html` in a modern browser. No server or build step is required.

## Included
- 64x32 wolf canvas
- Reference/template overlay using the supplied wolf texture
- Template labels for head, ears, eyes, muzzle, body, chest/mane, legs and tail
- Pixel pencil, eraser, fill, picker, line, rectangle, circle
- Selection, cut/copy/paste, move, layers, mirror, undo/redo
- PNG/JPG/WebP placement with resize/rotation/crop/stamp controls
- Live dynamic wolf preview
- Dark/light theme
- Bedrock `.mcpack` export with editable pack name/version/min engine/description
- Mobile share-sheet handoff for `.mcpack` when supported
- Windows best-effort Minecraft protocol launch after downloading
